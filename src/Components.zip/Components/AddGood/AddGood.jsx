import "./AddGood.css";

function AddGood() {

    return (
        <>
            <input type="button" value={"Aggiuni al carello"} className="AddGoodButton"/>
        </>
    );
}

export default AddGood;
